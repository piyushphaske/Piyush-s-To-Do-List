import express from 'express';
import Task from '../models/Task';
import jwt from 'jsonwebtoken';

const router = express.Router();
const JWT_SECRET = process.env.JWT_SECRET || 'secretkey';

// Middleware to verify JWT
function auth(req: any, res: any, next: any) {
  const token = req.headers['authorization']?.split(' ')[1];
  if (!token) return res.status(401).json({ message: 'No token provided' });
  try {
    const decoded = jwt.verify(token, JWT_SECRET) as { userId: string };
    req.userId = decoded.userId;
    next();
  } catch {
    res.status(401).json({ message: 'Invalid token' });
  }
}

// Get tasks for logged-in user
router.get('/', auth, async (req: any, res) => {
  try {
    const tasks = await Task.find({ userId: req.userId });
    res.json(tasks);
  } catch {
    res.status(500).json({ message: 'Server error' });
  }
});

// Add a new task
router.post('/', auth, async (req: any, res) => {
  const { title } = req.body;
  try {
    const task = new Task({ userId: req.userId, title });
    await task.save();
    res.status(201).json(task);
  } catch {
    res.status(500).json({ message: 'Server error' });
  }
});

// Update a task's title or completed status
router.patch('/:id', auth, async (req: any, res) => {
  const { id } = req.params;
  const { title, completed } = req.body;
  try {
    const update: any = {};
    if (title !== undefined) update.title = title;
    if (completed !== undefined) update.completed = completed;
    const task = await Task.findOneAndUpdate(
      { _id: id, userId: req.userId },
      update,
      { new: true }
    );
    if (!task) return res.status(404).json({ message: 'Task not found' });
    res.json(task);
  } catch {
    res.status(500).json({ message: 'Server error' });
  }
});

// Delete a task
router.delete('/:id', auth, async (req: any, res) => {
  const { id } = req.params;
  try {
    const task = await Task.findOneAndDelete({ _id: id, userId: req.userId });
    if (!task) return res.status(404).json({ message: 'Task not found' });
    res.json({ message: 'Task deleted' });
  } catch {
    res.status(500).json({ message: 'Server error' });
  }
});

export default router;