import mongoose, { Document, Schema } from 'mongoose';

export interface ITask extends Document {
  userId: string;
  title: string;
  completed: boolean;
}

const TaskSchema = new Schema<ITask>({
  userId: { type: Schema.Types.ObjectId, ref: 'User', required: true } as any, // Fix type error
  title: { type: String, required: true },
  completed: { type: Boolean, default: false },
});

export default mongoose.model<ITask>('Task', TaskSchema);
