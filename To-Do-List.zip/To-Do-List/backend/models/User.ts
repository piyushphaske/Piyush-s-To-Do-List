import mongoose, { Document, Schema } from 'mongoose';

export interface IUser extends Document {
  username: string;
  password: string;
  age?: number;
  phone?: string;
  email?: string;
  gender?: string;
}

const UserSchema = new Schema<IUser>({
  username: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  age: { type: Number },
  phone: { type: String },
  email: { type: String },
  gender: { type: String },
});

export default mongoose.model<IUser>('User', UserSchema);
