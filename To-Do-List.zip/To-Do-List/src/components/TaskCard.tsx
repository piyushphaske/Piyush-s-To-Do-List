import React from "react";
import { motion } from "framer-motion";

interface TaskCardProps {
  id: string;
  description: string;
  isCompleted?: boolean;
  onDelete?: (id: string) => void;
}

const TaskCard = ({
  id = "task-1",
  description = "Sample task description",
  isCompleted = false,
  onDelete,
}: TaskCardProps) => {
  return (
    <motion.div
      className={`w-full p-4 mb-3 rounded-lg shadow-sm border ${isCompleted ? "bg-gray-50 border-gray-200" : "bg-white border-gray-100"} cursor-grab hover:shadow-md transition-all duration-200`}
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      whileHover={{ scale: 1.02 }}
      whileDrag={{ scale: 1.05, boxShadow: "0 5px 15px rgba(0,0,0,0.1)" }}
      layout
      drag={false} // Actual dragging will be handled by Dragula
    >
      <div className="flex justify-between items-center">
        <p
          className={`text-sm ${isCompleted ? "text-gray-500 line-through" : "text-gray-800"}`}
        >
          {description}
        </p>
        {onDelete && (
          <button
            onClick={() => onDelete(id)}
            className="ml-2 text-gray-400 hover:text-red-500 transition-colors"
            aria-label="Delete task"
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M3 6h18" />
              <path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6" />
              <path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2" />
            </svg>
          </button>
        )}
      </div>
    </motion.div>
  );
};

export default TaskCard;
