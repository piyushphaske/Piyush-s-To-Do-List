import React from "react";
import { Card } from "./ui/card";

interface Task {
  id: string;
  description: string;
  completed: boolean;
}

interface TaskCardProps {
  id: string;
  description: string;
  completed: boolean;
  onDragStart?: (e: React.DragEvent, taskId: string) => void;
  onDelete?: (id: string) => void;
  onEdit?: (id: string, newTitle: string) => void;
}

// Inline TaskCard component since we're having import issues
const TaskCardComponent = ({
  id,
  description,
  completed,
  onDragStart,
  onDelete,
  onEdit,
}: TaskCardProps) => {
  const [isEditing, setIsEditing] = React.useState(false);
  const [editValue, setEditValue] = React.useState(description);

  const handleDragStart = (e: React.DragEvent) => {
    if (onDragStart) {
      onDragStart(e, id);
    }
  };

  const handleEdit = () => {
    setIsEditing(true);
  };

  const handleEditSave = () => {
    if (onEdit && editValue.trim() && editValue !== description) {
      onEdit(id, editValue.trim());
    }
    setIsEditing(false);
  };

  return (
    <div
      draggable
      onDragStart={handleDragStart}
      className={`p-4 rounded-lg shadow-sm cursor-move flex justify-between items-center ${
        completed
          ? "bg-green-50 border border-green-200"
          : "bg-white border border-gray-200"
      }`}
      data-task-id={id}
    >
      {isEditing ? (
        <>
          <input
            className="border rounded px-2 py-1 mr-2 flex-1"
            value={editValue}
            onChange={(e) => setEditValue(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") handleEditSave();
            }}
            autoFocus
          />
          <button
            className="text-green-600 mr-2"
            onClick={handleEditSave}
            title="Save"
          >
            ✔
          </button>
          <button
            className="text-gray-400 hover:text-red-500"
            onClick={() => setIsEditing(false)}
            title="Cancel"
          >
            ✖
          </button>
        </>
      ) : (
        <>
          <p
            className={`${
              completed ? "text-green-800 line-through" : "text-gray-800"
            } flex-1`}
          >
            {description}
          </p>
          <button
            onClick={handleEdit}
            className="ml-2 text-blue-400 hover:text-blue-700 transition-colors"
            aria-label="Edit task"
            title="Edit"
          >
            ✎
          </button>
          {onDelete && (
            <button
              onClick={() => onDelete(id)}
              className="ml-2 text-gray-400 hover:text-red-500 transition-colors"
              aria-label="Delete task"
              title="Delete"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M3 6h18" />
                <path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6" />
                <path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2" />
              </svg>
            </button>
          )}
        </>
      )}
    </div>
  );
};

interface TaskSectionProps {
  title: string;
  tasks: Task[];
  type: "pending" | "done";
  onDragStart?: (e: React.DragEvent, taskId: string) => void;
  onDragOver?: (e: React.DragEvent) => void;
  onDrop?: (e: React.DragEvent) => void;
}

const TaskSection = ({
  title = "Tasks",
  tasks = [],
  type = "pending",
  onDragStart,
  onDragOver,
  onDrop,
  onDelete,
  onEdit,
}: TaskSectionProps & { onDelete?: (id: string) => void; onEdit?: (id: string, newTitle: string) => void }) => {
  return (
    <Card className="flex flex-col h-full bg-background border-2 rounded-xl overflow-hidden">
      <div
        className={`p-4 ${type === "pending" ? "bg-blue-100" : "bg-green-100"}`}
      >
        <h2 className="text-xl font-bold">{title}</h2>
        <p className="text-sm text-muted-foreground">
          {type === "pending"
            ? "Drag tasks to the Done section when completed"
            : "Completed tasks appear here"}
        </p>
      </div>

      <div
        className="flex-1 p-4 overflow-y-auto min-h-[300px]"
        onDragOver={(e) => {
          e.preventDefault();
          if (onDragOver) onDragOver(e);
        }}
        onDrop={onDrop}
        data-section-type={type}
      >
        {tasks.length > 0 ? (
          <div className="space-y-3">
            {tasks.map((task) => (
              <TaskCardComponent
                key={task.id}
                id={task.id}
                description={task.description}
                completed={task.completed}
                onDragStart={onDragStart}
                onDelete={onDelete}
                onEdit={onEdit}
              />
            ))}
          </div>
        ) : (
          <div className="flex items-center justify-center h-full">
            <p className="text-muted-foreground text-center">
              {type === "pending"
                ? "No pending tasks. Add a new task above."
                : "No completed tasks yet. Drag tasks here when done."}
            </p>
          </div>
        )}
      </div>
    </Card>
  );
};

export default TaskSection;
export type { Task };
