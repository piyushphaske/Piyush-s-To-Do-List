import React, { useState } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { PlusCircle } from "lucide-react";

interface TaskInputProps {
  onAddTask: (task: string) => void;
}

const TaskInput = ({ onAddTask = () => {} }: TaskInputProps) => {
  const [taskText, setTaskText] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (taskText.trim()) {
      onAddTask(taskText.trim());
      setTaskText("");
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto p-4 bg-card rounded-lg shadow-sm border border-border">
      <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-3">
        <Input
          type="text"
          placeholder="Add a new task..."
          value={taskText}
          onChange={(e) => setTaskText(e.target.value)}
          className="flex-1"
        />
        <Button
          type="submit"
          disabled={!taskText.trim()}
          className="flex items-center gap-2"
        >
          <PlusCircle size={18} />
          <span>Add Task</span>
        </Button>
      </form>
    </div>
  );
};

export default TaskInput;
