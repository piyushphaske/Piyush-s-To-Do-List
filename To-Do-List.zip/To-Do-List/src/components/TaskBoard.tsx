import React, { useRef } from "react";
import { motion } from "framer-motion";
import TaskSection from "./TaskSection";

interface Task {
  id: string;
  text: string;
  completed: boolean;
}

interface TaskBoardProps {
  tasks?: Task[];
  onTaskMove?: (taskId: string, completed: boolean) => void;
}

interface TaskBoardTask {
  id: string;
  text: string;
  completed: boolean;
}

interface TaskSectionTask {
  id: string;
  description: string;
  completed: boolean;
}

const TaskBoard = ({ tasks = [], onTaskMove = () => {}, onDelete, onEdit }: TaskBoardProps & { onDelete?: (id: string) => void; onEdit?: (id: string, newTitle: string) => void }) => {
  const pendingTasks: TaskSectionTask[] = tasks
    .filter((task) => !task.completed)
    .map(({ id, text, completed }) => ({ id, description: text, completed }));
  const completedTasks: TaskSectionTask[] = tasks
    .filter((task) => task.completed)
    .map(({ id, text, completed }) => ({ id, description: text, completed }));

  const dragItem = useRef<{
    id: string;
    sourceSection: "pending" | "completed";
  } | null>(null);
  const dragOverItem = useRef<"pending" | "completed" | null>(null);

  // Fix drag handlers for TaskSection
  const handleSectionDragStart = (section: "pending" | "done") => (
    e: React.DragEvent,
    taskId: string,
  ) => {
    dragItem.current = {
      id: taskId,
      sourceSection: section === "pending" ? "pending" : "completed",
    };
  };

  const handleDragEnter = (section: "pending" | "completed") => {
    dragOverItem.current = section;
  };

  const handleDragEnd = () => {
    if (
      dragItem.current &&
      dragOverItem.current &&
      dragItem.current.sourceSection !== dragOverItem.current
    ) {
      const taskId = dragItem.current.id;
      const sourceSection = dragItem.current.sourceSection;
      const targetSection = dragOverItem.current;

      if (sourceSection === "pending" && targetSection === "completed") {
        // Move from pending to completed
        const taskToMove = pendingTasks.find((task) => task.id === taskId);
        if (taskToMove) {
          onTaskMove(taskId, true);
        }
      } else if (sourceSection === "completed" && targetSection === "pending") {
        // Move from completed to pending
        const taskToMove = completedTasks.find((task) => task.id === taskId);
        if (taskToMove) {
          onTaskMove(taskId, false);
        }
      }
    }

    // Reset drag references
    dragItem.current = null;
    dragOverItem.current = null;
  };

  return (
    <div className="w-full bg-background p-4 rounded-lg">
      <motion.div
        className="flex flex-col md:flex-row gap-6 w-full"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        <TaskSection
          title="Pending"
          tasks={pendingTasks}
          type="pending"
          onDragStart={handleSectionDragStart("pending")}
          onDragOver={() => handleDragEnter("pending")}
          onDrop={handleDragEnd}
          onDelete={onDelete}
          onEdit={onEdit}
        />
        <TaskSection
          title="Done"
          tasks={completedTasks}
          type="done"
          onDragStart={handleSectionDragStart("done")}
          onDragOver={() => handleDragEnter("completed")}
          onDrop={handleDragEnd}
          onDelete={onDelete}
          onEdit={onEdit}
        />
      </motion.div>
    </div>
  );
};

export default TaskBoard;
