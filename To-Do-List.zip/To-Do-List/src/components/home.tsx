import React, { useState, useEffect } from "react";
import TaskInput from "./TaskInput";
import TaskBoard from "./TaskBoard";
import AuthPage from "./AuthPage";
import { Button } from "./ui/button";
import { useNavigate } from "react-router-dom";

// Task type for Home state
interface Task {
  id: string;
  text: string;
  completed: boolean;
}

const API_URL = "http://localhost:5000/api";

const Home = () => {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [user, setUser] = useState<any>(null);
  const navigate = useNavigate();

  // Fetch tasks from backend
  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!token) return;
    fetch(`${API_URL}/tasks`, {
      headers: { Authorization: `Bearer ${token}` },
    })
      .then((res) => res.json())
      .then((data) => {
        if (Array.isArray(data)) {
          setTasks(
            data.map((t: any) => ({
              id: t._id,
              text: t.title,
              completed: t.completed,
            }))
          );
        }
      });
  }, [user]);

  // Add a new task to the backend
  const handleAddTask = (taskText: string) => {
    const token = localStorage.getItem("token");
    if (!token) return;
    fetch(`${API_URL}/tasks`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ title: taskText }),
    })
      .then((res) => res.json())
      .then((task) => {
        setTasks((prev) =>
          [...prev, { id: task._id, text: task.title, completed: task.completed }]
        );
      });
  };

  // Move task between pending and done (update backend)
  const handleTaskMove = (taskId: string, completed: boolean) => {
    const token = localStorage.getItem("token");
    if (!token) return;
    fetch(`${API_URL}/tasks/${taskId}`, {
      method: "PATCH",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ completed }),
    })
      .then((res) => res.json())
      .then((updated) => {
        setTasks((prev) =>
          prev.map((task) =>
            task.id === taskId ? { ...task, completed: updated.completed } : task
          )
        );
      });
  };

  // Edit a task's title in backend
  const handleEditTask = (taskId: string, newTitle: string) => {
    const token = localStorage.getItem("token");
    if (!token) return;
    fetch(`${API_URL}/tasks/${taskId}`, {
      method: "PATCH",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ title: newTitle }),
    })
      .then((res) => res.json())
      .then((updated) => {
        setTasks((prev) =>
          prev.map((task) =>
            task.id === taskId ? { ...task, text: updated.title } : task
          )
        );
      });
  };

  // Delete a task from backend
  const handleDeleteTask = (taskId: string) => {
    const token = localStorage.getItem("token");
    if (!token) return;
    fetch(`${API_URL}/tasks/${taskId}`, {
      method: "DELETE",
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
      .then((res) => res.json())
      .then(() => {
        setTasks((prev) => prev.filter((task) => task.id !== taskId));
      });
  };

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("userId");
    setUser(null);
    navigate("/login");
  };

  if (!user) {
    return <AuthPage onAuthSuccess={setUser} />;
  }

  return (
    <div className="min-h-screen bg-gray-50 p-4 md:p-8 flex flex-col items-center bg-background">
      <header className="w-full max-w-5xl mb-8 text-center flex flex-col md:flex-row md:justify-between md:items-center">
        <div>
          <h1 className="text-3xl md:text-4xl font-bold mb-2 text-primary">
            To-Do List
          </h1>
          <p className="text-muted-foreground">
            Add tasks using the input below. Drag and drop tasks between the
            Pending and Done sections.
          </p>
        </div>
        <Button
          onClick={handleLogout}
          className="mt-4 md:mt-0"
          variant="outline"
        >
          Logout
        </Button>
      </header>

      <main className="w-full max-w-5xl flex flex-col gap-6">
        <TaskInput onAddTask={handleAddTask} />
        <TaskBoard
          tasks={tasks}
          onTaskMove={handleTaskMove}
          onDelete={handleDeleteTask}
          onEdit={handleEditTask}
        />
      </main>

      <footer className="mt-auto pt-8 text-sm text-muted-foreground text-center w-full">
        <p>Drag and drop powered by Dragula.js</p>
      </footer>
    </div>
  );
};

export default Home;
